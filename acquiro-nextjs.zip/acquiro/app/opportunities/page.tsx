import { createClient } from '@/lib/supabase/server'
import type { Listing } from '@/types'
import NavPublic from '@/components/NavPublic'
import ListingCard from '@/components/ListingCard'

export const revalidate = 60

export default async function OpportunitiesPage() {
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()

  const { data: listings } = await supabase
    .from('listings')
    .select('*')
    .eq('status', 'approved')
    .order('created_at', { ascending: false })

  // Fetch user's existing access requests to show status
  let myRequests: Record<string, string> = {}
  if (user) {
    const { data: reqs } = await supabase
      .from('access_requests')
      .select('listing_id, status')
      .eq('buyer_id', user.id)
    if (reqs) {
      reqs.forEach(r => { myRequests[r.listing_id] = r.status })
    }
  }

  return (
    <div className="shell">
      <NavPublic user={user} />

      <div className="section">
        <div className="section-head">
          <div>
            <h2>Current Opportunities</h2>
            <p>All listings are shown with limited information. Deeper financials and seller identity are shared only after access is granted.</p>
          </div>
          {!user && (
            <a href="/auth?role=buyer" className="btn btn-teal">Sign in to request access</a>
          )}
        </div>

        {listings && listings.length > 0 ? (
          <div className="deal-grid">
            {(listings as Listing[]).map(l => (
              <ListingCard
                key={l.id}
                listing={l}
                user={user}
                existingRequestStatus={myRequests[l.id]}
              />
            ))}
          </div>
        ) : (
          <div className="empty">
            <h3>No opportunities listed yet</h3>
            <p>Check back soon — new opportunities are reviewed and added regularly.</p>
          </div>
        )}
      </div>

      <footer className="footer">
        <strong>Acquiro</strong>
        <span>Confidential business transactions for Nigerian SMEs.</span>
      </footer>
    </div>
  )
}
