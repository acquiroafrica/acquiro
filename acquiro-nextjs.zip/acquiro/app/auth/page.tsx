'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import type { Role } from '@/types'

export default function AuthPage() {
  const router = useRouter()
  const params = useSearchParams()
  const supabase = createClient()

  const [tab, setTab] = useState<'login' | 'signup'>('login')
  const [role, setRole] = useState<Role>('buyer')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  useEffect(() => {
    const r = params.get('role')
    if (r === 'seller') { setRole('seller'); setTab('signup') }
  }, [params])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (tab === 'signup') {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
      })
      if (signUpError) { setError(signUpError.message); setLoading(false); return }

      // Save role
      if (data.user) {
        await supabase.from('user_roles').insert({ user_id: data.user.id, role })
      }

      setSuccess('Account created! Check your email to confirm, then log in.')
      setTab('login')
    } else {
      const { error: loginError } = await supabase.auth.signInWithPassword({ email, password })
      if (loginError) { setError(loginError.message); setLoading(false); return }

      // Fetch role to redirect appropriately
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: roleRow } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single()
        const r = roleRow?.role ?? 'buyer'
        router.push(r === 'seller' ? '/dashboard' : '/opportunities')
        router.refresh()
      }
    }
    setLoading(false)
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <img src="/acquiro-logo.png" alt="Acquiro" style={{ height: 40, width: 'auto', marginBottom: 12 }} />
        <p>The confidential marketplace for Nigerian SME transactions.</p>

        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Log in</button>
          <button className={`auth-tab ${tab === 'signup' ? 'active' : ''}`} onClick={() => setTab('signup')}>Create account</button>
        </div>

        {error && <div className="alert alert-error">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <form onSubmit={handleSubmit}>
          {tab === 'signup' && (
            <>
              <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 12, color: 'var(--ink)' }}>I am a…</p>
              <div className="role-grid" style={{ marginBottom: 20 }}>
                <div className={`role-card ${role === 'buyer' ? 'selected' : ''}`} onClick={() => setRole('buyer')}>
                  <h4>Buyer</h4>
                  <p>Looking to acquire or invest</p>
                </div>
                <div className={`role-card ${role === 'seller' ? 'selected' : ''}`} onClick={() => setRole('seller')}>
                  <h4>Seller</h4>
                  <p>Exploring an exit or partnership</p>
                </div>
              </div>
            </>
          )}

          <div className="form-group">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder={tab === 'signup' ? 'Min 8 characters' : 'Your password'}
              minLength={tab === 'signup' ? 8 : 1}
            />
          </div>

          <button type="submit" className="btn btn-teal btn-full" disabled={loading}>
            {loading ? 'Please wait…' : tab === 'login' ? 'Log in' : 'Create account'}
          </button>
        </form>

        <p style={{ fontSize: 13, color: 'var(--muted)', textAlign: 'center', marginTop: 20 }}>
          <a href="/" style={{ color: 'var(--teal)' }}>← Back to home</a>
        </p>
      </div>
    </div>
  )
}
