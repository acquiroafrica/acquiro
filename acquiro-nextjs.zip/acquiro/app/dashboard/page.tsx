import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import type { Listing } from '@/types'
import DashboardShell from '@/components/DashboardShell'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth')

  const { data: roleRow } = await supabase
    .from('user_roles')
    .select('role')
    .eq('user_id', user.id)
    .single()

  // Buyers have no dashboard — send to opportunities
  if (roleRow?.role === 'buyer') redirect('/opportunities')

  const { data: listings } = await supabase
    .from('listings')
    .select('*')
    .eq('seller_id', user.id)
    .order('created_at', { ascending: false })

  const statusBadge = (s: string) => {
    const cls = s === 'approved' ? 'badge-approved' : s === 'rejected' ? 'badge-rejected' : 'badge-pending'
    return <span className={`tag ${cls}`} style={{ textTransform: 'capitalize' }}>{s}</span>
  }

  return (
    <DashboardShell role="seller" email={user.email ?? ''}>
      <h1 className="page-title">My Listings</h1>
      <p className="page-sub">Listings you have submitted. New listings are reviewed before going live.</p>

      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'flex-end' }}>
        <Link href="/listings/new" className="btn btn-gold">+ New listing</Link>
      </div>

      {listings && listings.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Sector</th>
                <th>State</th>
                <th>Asking price</th>
                <th>Deal type</th>
                <th>Status</th>
                <th>Submitted</th>
              </tr>
            </thead>
            <tbody>
              {(listings as Listing[]).map(l => (
                <tr key={l.id}>
                  <td style={{ fontWeight: 600 }}>{l.title}</td>
                  <td>{l.sector}</td>
                  <td>{l.state}</td>
                  <td>{l.asking_price}</td>
                  <td>{l.deal_type}</td>
                  <td>{statusBadge(l.status)}</td>
                  <td style={{ color: 'var(--muted)' }}>{new Date(l.created_at).toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="empty">
          <h3>No listings yet</h3>
          <p>Create your first confidential listing to start receiving qualified buyer interest.</p>
          <Link href="/listings/new" className="btn btn-gold" style={{ marginTop: 20, display: 'inline-flex' }}>
            Create a listing
          </Link>
        </div>
      )}
    </DashboardShell>
  )
}
